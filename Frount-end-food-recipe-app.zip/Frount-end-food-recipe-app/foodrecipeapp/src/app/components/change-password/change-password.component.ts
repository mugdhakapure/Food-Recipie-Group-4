import { Component, OnInit } from '@angular/core';
import { FoodrecipedetailsService } from 'src/app/services/foodrecipedetails.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {


  username = '' ;

  userDetails = null ;

  message = null ;

  currentpassword = '' ;

  newpassword = '' ;

  confirmpassword = '' ;

  submitted = false;

  oldpassword= '';

  constructor(private userDetailsService: FoodrecipedetailsService,
    private cookieService: CookieService) { }

  ngOnInit(): void {

    this.getusername();

  }

  getusername(){
    this.username =   this.cookieService.get('username');
    console.log('username'+this.username);
    this.oldpassword = this.cookieService.get('password');
  }

  updateUserDetails(){

    if(this.currentpassword == ''){
      this.message = 'Current Password should not be empty.'
      return;
    }

    if(this.currentpassword !== this.oldpassword){
      this.message = 'Please enter correct current password.'
      return;
    }

    if(this.newpassword == ''){
      this.message = 'New password should not be empty.'
      return;
    }


     if(this.newpassword !== this.confirmpassword){
      this.message = 'Password and confirmpassword shoud be same.'
      return;
    }

    const data = {
      userName: this.username,
      password: this.newpassword
    };

    this.userDetailsService.updateuser(data)
      .subscribe(
        response => {
          this.message = null ;
          this.submitted = true ;
          this.cookieService.set('password', this.newpassword);
        },
        error => {
         
          console.log(error);
          this.message = 'Some error occured while changing password';
        });

  }



}

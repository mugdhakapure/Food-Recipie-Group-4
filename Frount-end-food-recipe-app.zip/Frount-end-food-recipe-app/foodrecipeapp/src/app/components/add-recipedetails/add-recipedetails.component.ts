import { Component, OnInit } from '@angular/core';
import { FoodrecipedetailsService } from 'src/app/services/foodrecipedetails.service';

@Component({
  selector: 'app-add-recipedetails',
  templateUrl: './add-recipedetails.component.html',
  styleUrls: ['./add-recipedetails.component.scss']
})
export class AddRecipedetailsComponent implements OnInit {

  recipedetails = {
    item: '',
    name: '',
    ingradiants: '',
    steps: ''
  };
  submitted = false;
  isNotValidRecipe = false;
  errorMessage = 'Receipe Already exist for specified Item'

  constructor(private recipeDetailsService: FoodrecipedetailsService) { }

  ngOnInit(): void {
  }

  saveRecipeDetails() {
    const data = {
      item: this.recipedetails.item,
      name: this.recipedetails.name,
      ingradiants: this.recipedetails.ingradiants,
      steps: this.recipedetails.steps
    };

  this.recipeDetailsService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
          this.isNotValidRecipe = true;
          this.errorMessage = 'Receipe ' + this.recipedetails.name + ' already exist for Item ' + this.recipedetails.item;

        });
    }

   newRecipeDetails() {
    this.submitted = false;
    this.recipedetails = {
       item: '',
       name: '',
       ingradiants: '',
       steps: ''
    };
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRecipedetailsComponent } from './add-recipedetails.component';

describe('AddRecipedetailsComponent', () => {
  let component: AddRecipedetailsComponent;
  let fixture: ComponentFixture<AddRecipedetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddRecipedetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRecipedetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FoodrecipedetailsService } from 'src/app/services/foodrecipedetails.service';

@Component({
  selector: 'app-recipe-details',
  templateUrl: './recipe-details.component.html',
  styleUrls: ['./recipe-details.component.scss']
})
export class RecipeDetailsComponent implements OnInit {

  recipedetails: any;
  currentRecipeDetails = null;
  currentIndex = -1;
  recipeName= '' ;

  constructor(private recipeDetailsService: FoodrecipedetailsService) { }

  ngOnInit(): void {
  }

  setActiveRecipeDetails(recipeDetail, index) {
    this.currentRecipeDetails = recipeDetail;
    this.currentIndex = index;
  }

 searchRecipe() {
  console.log(this.recipeName);
    this.recipeDetailsService.get(this.recipeName)
      .subscribe(
        data => {
          this.recipedetails = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

}

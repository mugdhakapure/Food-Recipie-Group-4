import { Component, OnInit } from '@angular/core';
import { FoodrecipedetailsService } from 'src/app/services/foodrecipedetails.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-registration-details',
  templateUrl: './registration-details.component.html',
  styleUrls: ['./registration-details.component.scss']
})
export class RegistrationDetailsComponent implements OnInit {

  userdetails = {
    userName: '',
    firstName: '',
    lastName: '',
    email: '',
    password:'',
    confirmpassword: ''
  };
  submitted = false;

  errorMessage = 'User already Exist';
  invalidCreate = false;

  constructor(
    private router: Router,
    private userDetailsService: FoodrecipedetailsService) { }

  ngOnInit(): void {
  }

  cancelUserDetails() {
    this.router.navigate(['/login']);
  }

  saveUserDetails() {

  if(this.userdetails.userName == ''){
      this.invalidCreate = true;
      this.errorMessage = 'User Name should not be empty.'
      return;
    }

    if(this.userdetails.firstName == ''){
      this.invalidCreate = true;
      this.errorMessage = 'First Name should not be empty.'
      return;
    }

     if(this.userdetails.email == ''){
      this.invalidCreate = true;
      this.errorMessage = 'Email should not be empty.'
      return;
    }

     if(this.userdetails.password == ''){
      this.invalidCreate = true;
      this.errorMessage = 'Password should not be empty.'
      return;
    }



     if(this.userdetails.password !== this.userdetails.confirmpassword){
      this.invalidCreate = true;
      this.errorMessage = 'Password and confirmpassword shoud be match.'
      return;
    }


    const data = {
      userName: this.userdetails.userName,
      firstName: this.userdetails.firstName,
      lastName: this.userdetails.lastName,
      email: this.userdetails.email,
      password: this.userdetails.password
    };
   
console.log(data);
  this.userDetailsService.registerUser(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
          this.router.navigate(['/login']);
        },
        error => {
          this.invalidCreate = true;
          this.errorMessage = 'User Already Exists.'
          console.log(error);
        });
    }

    newUserDetails() {
    this.submitted = false;
    this.userdetails = {
        userName: '',
        firstName: '',
        lastName: '',
        email: '',
        password:'',
        confirmpassword: ''
    };
    this.invalidCreate = false;

  }



}

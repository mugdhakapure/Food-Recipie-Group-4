import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { FoodrecipedetailsService } from 'src/app/services/foodrecipedetails.service';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  username: string;
  password : string;
  errorMessage = 'Invalid Credentials';
  successMessage: string;
  invalidLogin = false;
  loginSuccess = false;
  userrole = 'admin';

  usercred = null;

  constructor(
    private router: Router,
    private authenticationService: FoodrecipedetailsService,
    private cookieService: CookieService
    ) { }

  ngOnInit(): void {
  }

   handleLogin() {
    const data = {
      username: this.username,
      password: this.password
    }
    console.log(data);
   /* this.authenticationService.authenticationService(data).subscribe((result)=> {
      console.log('success');
      this.invalidLogin = false;
      this.loginSuccess = true;
      this.successMessage = 'Login Successful.';
      this.router.navigate(['/foodrecipedetails']);
    }, () => {
      console.log('error');
     // this.invalidLogin = true;
     // this.loginSuccess = false;
      this.invalidLogin = false;
      this.loginSuccess = true;
      this.successMessage = 'Login Successful.';
      this.router.navigate(['/foodrecipedetails']);
    }); */

       this.authenticationService.basicauth(data)
      .subscribe(
        response => {
      console.log(response);
      console.log('success');
      this.invalidLogin = false;
      this.loginSuccess = true;
      this.successMessage = 'Login Successful.';
      this.usercred = response;
      this.cookieService.set('username', this.username);
      this.cookieService.set('password', this.password);
      console.log('usercred' + this.usercred.role);
      if(this.usercred.role == 'user' ){
      this.router.navigate(['/foodrecipedetailsUser']);
      } else {
        this.router.navigate(['/foodrecipedetailsAdmin']);
      }
        },
        error => {
          console.log(error);
          this.invalidLogin = true;
      this.loginSuccess = false;
      this.errorMessage = 'Invalid Credentials';
        });

      
  }

  handleuserregister(){
    console.log('redirecting to signup');
    this.router.navigate(['/signup']);
  }




  }



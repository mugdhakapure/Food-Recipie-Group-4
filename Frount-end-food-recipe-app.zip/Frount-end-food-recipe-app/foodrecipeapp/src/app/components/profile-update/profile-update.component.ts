import { Component, OnInit } from '@angular/core';
import { FoodrecipedetailsService } from 'src/app/services/foodrecipedetails.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-profile-update',
  templateUrl: './profile-update.component.html',
  styleUrls: ['./profile-update.component.scss']
})
export class ProfileUpdateComponent implements OnInit {

  recipedetails: any;
  currentRecipeDetails = null;
  currentIndex = -1;
  recipeName= '' ;
  username = '';

  userDetails = null;

  editdata = false;

  isgetting = false;


  constructor(private userDetailsService: FoodrecipedetailsService,
    private cookieService: CookieService) { }

  ngOnInit(): void {

    this.retrieveProfileDetails();
  }


   retrieveProfileDetails() {
    this.username =   this.cookieService.get('username');;

    console.log(this.username);

    this.userDetailsService.getuser(this.username)
      .subscribe(
        data => {
          this.userDetails = data;
          this.isgetting = true;
          this.editdata = false;
          console.log(data);
        },
        error => {
          console.log(error);
        });

    
  }


  refreshList() {
    this.retrieveProfileDetails();
    
  }

  editprofile(){

    this.editdata = true ;


    this.isgetting = false;
  }

  updateUserDetails(){

    const data = {
      userName: this.userDetails.userName,
      firstName: this.userDetails.firstName,
      lastName: this.userDetails.lastName,
      email: this.userDetails.email
    };

    this.userDetailsService.updateuser(data)
      .subscribe(
        response => {
          console.log(response);
          this.retrieveProfileDetails();
        },
        error => {
         
          console.log(error);
        });

  }

  

}

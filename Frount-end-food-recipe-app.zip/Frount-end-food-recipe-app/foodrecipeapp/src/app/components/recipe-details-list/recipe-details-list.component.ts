import { Component, OnInit } from '@angular/core';
import { FoodrecipedetailsService } from 'src/app/services/foodrecipedetails.service';

@Component({
  selector: 'app-recipe-details-list',
  templateUrl: './recipe-details-list.component.html',
  styleUrls: ['./recipe-details-list.component.scss']
})
export class RecipeDetailsListComponent implements OnInit {

  recipedetails: any;
  currentRecipeDetails = null;
  currentIndex = -1;
  recipeName= '' ;


  constructor(private recipeDetailsService: FoodrecipedetailsService) { }

  ngOnInit(): void {

    this.retrieveRecipeDetails();
  }

   retrieveRecipeDetails() {
    this.recipeDetailsService.getAll()
      .subscribe(
        data => {
          this.recipedetails = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  refreshList() {
    this.retrieveRecipeDetails();
    this.currentRecipeDetails = null;
    this.currentIndex = -1;
  }

  setActiveRecipeDetails(recipeDetail, index) {
    this.currentRecipeDetails = recipeDetail;
    this.currentIndex = index;
  }

  deleteUserDetails(data){
    console.log(data.receipeId);
    this.recipeDetailsService.deleterecipe(data.receipeId)
      .subscribe(
        data => {
          console.log('success');
          this.retrieveRecipeDetails();
          this.currentRecipeDetails = null;
          this.currentIndex = -1;
        },
        error => {
          console.log(error);
        });
  }

 

}

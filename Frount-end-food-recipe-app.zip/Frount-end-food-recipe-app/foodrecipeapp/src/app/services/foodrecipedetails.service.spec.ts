import { TestBed } from '@angular/core/testing';

import { FoodrecipedetailsService } from './foodrecipedetails.service';

describe('FoodrecipedetailsService', () => {
  let service: FoodrecipedetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FoodrecipedetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

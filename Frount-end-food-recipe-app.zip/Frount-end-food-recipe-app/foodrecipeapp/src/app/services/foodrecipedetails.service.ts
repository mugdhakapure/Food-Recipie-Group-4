import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

const baseUrlGetAll = 'http://localhost:8080/foodrecipe/recipedetails';
const baseUrlGetById = 'http://localhost:8080/foodrecipe/recipedetails';
const baseUrlCreate = 'http://localhost:8080/foodrecipe/addrecipedetails';
const baseUrl = 'http://localhost:8080/foodrecipe/' ;
const baseUrlBasicAuth = 'http://localhost:8080/foodrecipe/basicauth' ;
const baseUrlRegisterUser = 'http://localhost:8080/foodrecipe/adduser' ;
const baseUrlGetuser = 'http://localhost:8080/foodrecipe/user' ;
const baseUrlUpdateUser = 'http://localhost:8080/foodrecipe/updateuser' ;
const baseUrldeleteRecipe = 'http://localhost:8080/foodrecipe/recipedetails';

@Injectable({
  providedIn: 'root'
})

export class FoodrecipedetailsService {

 
  constructor(private http: HttpClient) { }

  getAll() {

    return this.http.get(baseUrlGetAll);
  }

  get(id) {
    return this.http.get(`${baseUrlGetById}/${id}`);
  }

  create(data) {
    return this.http.post(baseUrlCreate, data);
  }

 update(id, data) {
    return this.http.put(`${baseUrl}/${id}`, data);
  }

  delete(id) {
    return this.http.delete(`${baseUrl}/${id}`);
  }

  deleteAll() {
    return this.http.delete(baseUrl);
  }

  basicauth(data) {

    return this.http.post(baseUrlBasicAuth, data);
  }

  registerUser(data) {
    return this.http.post(baseUrlRegisterUser, data);
  }

  getuser(name) {
    return this.http.get(`${baseUrlGetuser}/${name}`);
  }

  updateuser(data) {
    return this.http.put(baseUrlUpdateUser, data);
  }

  deleterecipe(id) {
    return this.http.delete(`${baseUrldeleteRecipe}/${id}`);
  }


}

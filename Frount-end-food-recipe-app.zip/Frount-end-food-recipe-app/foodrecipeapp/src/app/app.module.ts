import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddRecipedetailsComponent } from './components/add-recipedetails/add-recipedetails.component';
import { RecipeDetailsComponent } from './components/recipe-details/recipe-details.component';
import { RecipeDetailsListComponent } from './components/recipe-details-list/recipe-details-list.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './components/login/login.component';
import { RegistrationDetailsComponent } from './components/registration-details/registration-details.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ProfileUpdateComponent } from './components/profile-update/profile-update.component';

@NgModule({
  declarations: [
    AppComponent,
    AddRecipedetailsComponent,
    RecipeDetailsComponent,
    RecipeDetailsListComponent,
    LoginComponent,
    RegistrationDetailsComponent,
    ChangePasswordComponent,
    ProfileUpdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
